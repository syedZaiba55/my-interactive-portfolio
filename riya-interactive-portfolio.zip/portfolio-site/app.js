(() => {
  const frameImage = document.querySelector('#character-frame');
  const stage = document.querySelector('#character-stage');
  const pupils = [...document.querySelectorAll('.pupil')];
  const readout = document.querySelector('#tracking-readout');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let frames = [];
  let frameIndex = 0;
  let nextFrameAt = 0;
  let pointer = { x: window.innerWidth * .5, y: window.innerHeight * .42 };
  let current = { x: 0, y: 0 };
  let target = { x: 0, y: 0 };
  let lastPointer = performance.now();

  fetch('/frames/manifest.json')
    .then((res) => res.json())
    .then((manifest) => {
      frames = manifest.frames.map((frame) => frame.src);
      frames.forEach((src) => { const preload = new Image(); preload.src = src; });
      if (!reducedMotion) requestAnimationFrame(animateFrames);
    })
    .catch(() => {
      if (readout) readout.textContent = 'tracking: ready';
    });

  function animateFrames(now) {
    if (now >= nextFrameAt && frames.length) {
      frameImage.src = frames[frameIndex];
      frameIndex = (frameIndex + 1) % frames.length;
      nextFrameAt = now + 333;
    }
    requestAnimationFrame(animateFrames);
  }

  function updateTarget(clientX, clientY) {
    pointer.x = clientX;
    pointer.y = clientY;
    // Map the real viewport cursor to a gentle, bounded eye vector.
    target.x = Math.max(-1, Math.min(1, (clientX / window.innerWidth - .5) * 2));
    target.y = Math.max(-1, Math.min(1, (clientY / window.innerHeight - .45) * 1.8));
    lastPointer = performance.now();
  }

  window.addEventListener('pointermove', (event) => updateTarget(event.clientX, event.clientY), { passive: true });
  window.addEventListener('touchmove', (event) => {
    const touch = event.touches[0];
    if (touch) updateTarget(touch.clientX, touch.clientY);
  }, { passive: true });

  function animateEyes() {
    current.x += (target.x - current.x) * .14;
    current.y += (target.y - current.y) * .14;
    pupils.forEach((pupil) => {
      const x = current.x * 42;
      const y = current.y * 21;
      pupil.style.transform = `translate(calc(-50% + ${x.toFixed(2)}%), calc(-50% + ${y.toFixed(2)}%))`;
    });
    if (readout) {
      const fresh = performance.now() - lastPointer < 1600;
      readout.textContent = fresh ? `tracking: ${current.x.toFixed(2)}, ${current.y.toFixed(2)}` : 'tracking: on';
    }
    requestAnimationFrame(animateEyes);
  }
  animateEyes();
})();
