# Riya Mehta — Interactive portfolio

Plain-local portfolio site built from the supplied character image and MP4.

## Run locally

```bash
python3 -m http.server 4173
```

Open `http://localhost:4173`.

## Interactive character

The MP4 was used only at build time. Python/OpenCV extracted 31 JPEG frames at roughly 3 frames per second from the 10.07-second source. The extracted sequence is kept in `public/frames/` and mirrored at the served root `frames/` for the zero-dependency Python static server.

The browser animates those still frames and uses `pointermove` coordinates to smoothly reposition the two pupil overlays in real time. No `<video>` element, runtime MP4 playback, or runtime seeking is used.

## Verified

- HTML, CSS, JavaScript, frame manifest, and frame assets return HTTP 200.
- Browser page loads with the extracted character frames.
- Moving the real browser pointer changes the pupil CSS transforms.
- Runtime DOM contains zero video elements.
